<div class="cards">
  <div class="card c-blue"><span>Paket Aktif</span><b><?= $aktif ?></b></div>
  <div class="card c-green"><span>Sedang Tender</span><b><?= $tender ?></b></div>
  <div class="card c-orange"><span>Selesai</span><b><?= $selesai ?></b></div>
  <div class="card c-red"><span>Total Pengguna</span><b><?= $totalUser ?></b></div>
</div>

<h2>Status Ketepatan Waktu</h2>
<div class="cards wide3">
  <div class="card c-blue"><span>Lebih Cepat</span><b><?= $cepat ?></b></div>
  <div class="card c-green"><span>Tepat Waktu</span><b><?= $tepat ?></b></div>
  <div class="card c-red"><span>Delay</span><b><?= $delay ?></b></div>
</div>

<h2>Rekap per Jenis Paket</h2>
<table><thead><tr><th>Jenis Paket</th><th>Jumlah Paket</th><th>Lebih Cepat</th><th>Tepat Waktu</th><th>Delay</th></tr></thead><tbody>
<?php foreach ($rekap as $j => $r): ?>
<tr><td><?= $e($j) ?></td><td><?= $r['total'] ?></td><td><?= $r['cepat'] ?></td><td><?= $r['tepat'] ?></td><td><?= $r['delay'] ?></td></tr>
<?php endforeach; ?></tbody></table>

<h2>Paket per Tahap</h2>
<form method="get" action="index.php" class="filter">
  <input type="hidden" name="page" value="dashboard">
  <label>Jenis Paket<select name="jenis"><option value="">Semua</option>
    <?php foreach (PaketPengadaan::JENIS as $j): ?><option <?= $fJenis === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach; ?></select></label>
  <label>Status<select name="ket"><option value="">Semua</option>
    <?php foreach (['cepat' => 'Lebih cepat', 'tepat' => 'Tepat waktu', 'delay' => 'Delay'] as $k => $l): ?><option value="<?= $k ?>" <?= $fStatus === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></label>
  <button class="btn" type="submit">Terapkan</button>
  <a class="btn ghost" href="index.php?page=dashboard">Reset</a>
</form>

<?php foreach ($perTahap as $no => $items):
  $judul = $no === 0 ? 'Belum dimulai' : "Tahap $no - " . Tender::TAHAP[$no - 1]; ?>
<h3><?= $e($judul) ?> <span class="muted">(<?= count($items) ?> paket)</span></h3>
<table><thead><tr><th>Nama Paket</th><th>Jenis Paket</th><th>Status Paket</th><th>Ketepatan Waktu</th></tr></thead><tbody>
<?php if (!$items): ?><tr><td colspan="4" class="muted">Tidak ada paket</td></tr><?php endif; ?>
<?php foreach ($items as $p): ?>
<tr><td><a href="index.php?page=progres&id=<?= $p['id'] ?>"><?= $e($p['nama_paket']) ?></a></td><td><?= $e($p['jenis_paket']) ?></td>
<td class="st-<?= strtolower($p['status']) ?>"><?= $e($p['status']) ?></td><td><?= $kt($p['ket']) ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php endforeach; ?>

<h2>Progres Pengadaan Terbaru</h2>
<table><thead><tr><th>Nama Paket</th><th>Jenis Paket</th><th>Status</th><th>Tahap</th><th>Ketepatan Waktu</th></tr></thead><tbody>
<?php if (!$terbaru): ?><tr><td colspan="5" class="muted">Belum ada data</td></tr><?php endif; ?>
<?php foreach ($terbaru as $p): ?>
<tr><td><a href="index.php?page=progres&id=<?= $p['id'] ?>"><?= $e($p['nama_paket']) ?></a></td><td><?= $e($p['jenis_paket']) ?></td>
<td class="st-<?= strtolower($p['status']) ?>"><?= $e($p['status']) ?></td><td><?= $e($p['tahap_aktif'] ?? '-') ?></td><td><?= $kt($p['ket']) ?></td></tr>
<?php endforeach; ?></tbody></table>
